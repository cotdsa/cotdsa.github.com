#! /usr/bin/env python
"""Python helper to create, join and rebalance CouchBase clusters
Usage: python couchbase-cluster-helper.py [options] command

Options:
  -a ..., --access=...         AWS Access Key ID [ or AWS_ACCESS_KEY_ID env var ]
  -s ..., --secret=...         AWS Secret Access Key [ or AWS_SECRET_ACCESS_KEY env var ]
  -p ..., --cb-port=...        CouchBase API Port [ Default 8091 ]
  -u ..., --cb-user=...        CouchBase API User [ Default Administrator ]
  -w ..., --cb-pass=...        CouchBase API Pass [ Default Administrator ]
  -b ..., --cb-bucket=...      CouchBase Bucket Name [ Default default ]
  -m ..., --cb-memory=...      Couchbase bucket memory quota in MB [ Default 200 ]
  -r ..., --vpc-role=...       VPC Role to filter available nodes [ Default Autodetect ]
  -t, --wait-rebalance         Wait for rebalance to finish, show progress if verbose
  -v, --verbose                Enable verbose output
  -h, --help                   Show this help

Commands:
  [create]                Create a new local cluster
  [join]                  Search for a cluster and join it
  [leave]                 Leave the current cluster and rebalance
  [rebalance]             Trigger cluster rebalancing
  [auto]                  Automatic mode. See below.

NOTE: Automatic mode
1- Look for a cluster by VPC-ROLE
~if no cluster is found~
2- Compute election algorithm ( lowest MAC in the pool )
3- If designated master create a new local cluster
~else~
2- Join existing cluster
3- Rebalance cluster

"""
import sys
import os
import getopt
import random
import json
import time
try:
  import boto
  import boto.ec2
except ImportError:
  sys.stderr.write("This script requires the `boto` library.\nInstall with `pip install boto`\n")
  sys.exit(-1)
try:
  import requests
except ImportError:
  sys.stderr.write("This script requires the `requests` library.\nInstall with `pip install requests`\n")
  sys.exit(-1)

class couchBaseHelper:
  AWS_ACCESS_KEY_ID = None
  AWS_SECRET_ACCESS_KEY = None
  verbose = False
  wait_rebalance = False
  couchbase_port = 8091
  couchbase_user = "Administrator"
  couchbase_pass = "password"
  couchbase_bucket = "default"
  couchbase_memory = 200

  rest_endpoint_status            = "/pools/default" 
  rest_endpoint_nodestatus        = "/nodeStatuses"
  rest_endpoint_addnode           = "/controller/addNode"
  rest_endpoint_delnode           = "/controller/ejectNode"
  rest_endpoint_rebalance         = "/controller/rebalance"
  rest_endpoint_rebalance_status  = "/pools/default/rebalanceProgress"
  rest_endpoint_settings          = "/settings/web"
  rest_endpoint_createbucket      = "/pools/default/buckets/"
  rest_endpoint_failover          = "/controller/failOver"

  region = None
  instance_id = None
  vpc_role = None
  instance_state = "running"
  ec2connection = None

  def __init__(self):
    self.region = boto.utils.get_instance_identity()['document']['region']
    self.instance_id = boto.utils.get_instance_metadata()['instance-id']

  def connect_ec2(self):
    if ( isinstance(self.ec2connection, boto.ec2.connection.EC2Connection) ):
      return self.ec2connection
    region = boto.ec2.get_region(self.region)
    if ( self.AWS_ACCESS_KEY_ID is not None and self.AWS_SECRET_ACCESS_KEY is not None):
      self.ec2connection = boto.ec2.connection.EC2Connection(aws_access_key_id=self.AWS_ACCESS_KEY_ID, aws_secret_access_key=self.AWS_SECRET_ACCESS_KEY, region=region)
    else:
      self.ec2connection = boto.ec2.connection.EC2Connection(region=region)
    return self.ec2connection

  def _get_local_inst(self):
    return self.connect_ec2().get_all_instances(filters={'instance-id' : self.instance_id})[0].instances[0]

  def _get_vpc_role(self):
    if self.vpc_role is None:
      try:
        self.vpc_role = self.connect_ec2().get_all_tags(filters={ 'key' : 'vpc-role', 'resource-id' : self.instance_id })[0].value
      except IndexError:
        self.vpc_role = self.connect_ec2().get_all_tags(filters={ 'key' : 'role', 'resource-id' : self.instance_id })[0].value
    return self.vpc_role

  def _get_instances_list(self):
    reservations = self.connect_ec2().get_all_instances(filters={'instance-state-name' : self.instance_state, 'tag:vpc-role' : self._get_vpc_role()})    
    if not reservations:
      reservations = self.connect_ec2().get_all_instances(filters={'instance-state-name' : self.instance_state, 'tag:role' : self._get_vpc_role()})
    instances = [i for r in reservations for i in r.instances]
    return instances

  # Returns a list of tuples with instance object and integer representation of its MAC address, ready to be sorted
  def _get_network_macs(self, instances_list):
    return map(lambda x: (x, int(x.interfaces[0].mac_address.replace(':', ''), 16)), instances_list)
       

  def get_elegible_master_instance(self):
    sorted_list = sorted(self._get_network_macs(self._get_instances_list()), key=lambda mactuple: mactuple[1])
    lowest = sorted_list[0]
    return lowest[0]
  
  def should_i_be_master(self):
    return self.instance_id == self.get_elegible_master_instance().id

  def is_a_cluster(self, ipaddress):
    if self.verbose:
      sys.stderr.write("Retrieving cluster status from %s:%d\n" % (ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (ipaddress, self.couchbase_port, self.rest_endpoint_status)
    try:
        c_stat = requests.get(r_url, auth=(self.couchbase_user, self.couchbase_pass))
    except requests.ConnectionError:
        return False
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % c_stat.status_code)
    return c_stat.status_code == 200

  def find_cb_cluster(self):
    cluster_nodes = []
    for instance in self._get_instances_list():
      ipaddress = instance.private_ip_address
      if self.is_a_cluster(ipaddress) and self._get_local_inst().private_ip_address != ipaddress:
        cluster_nodes.append(instance)
    return cluster_nodes

  def _get_nodes_in_cluster(self, ipaddress):
    if self.verbose:
      sys.stderr.write("Retrieving nodes in %s:%d cluster\n" % (ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (ipaddress, self.couchbase_port, self.rest_endpoint_nodestatus)
    r_nodes = requests.get(r_url, auth=(self.couchbase_user, self.couchbase_pass))
    if r_nodes.status_code == 200:
      return json.loads(r_nodes.content)
    else:
      return None

  def _check_cluster(self, cluster_nodes):
    avg_len = -1
    for node in cluster_nodes:
      ipaddress = node.private_ip_address
      c_nodes = self._get_nodes_in_cluster(ipaddress)
      nodecount = len(c_nodes.keys())
      for c_node in c_nodes:
        if c_nodes[c_node]["status"] != "healthy":
          if self.verbose:
            sys.stderr.write("Cluster %s:%d reports node %s as not healty\n" % (ipaddress, self.couchbase_port, c_node))
          return False
      if ( avg_len != -1 and nodecount != avg_len ):
        if self.verbose:
          sys.stderr.write("Cluster %s:%d has an inconsistnt node count\n" % (ipaddress, self.couchbase_port))
        return False
      avg_len = nodecount
    return True

  def _get_random_node(self, cluster_nodes):
    count = len(cluster_nodes)
    rand = random.randint(0, count-1)
    if self.verbose:
      sys.stderr.write("Dice roll: %d = %s\n" % (rand, cluster_nodes[rand]))
    return cluster_nodes[rand]

  def _join_cb_cluster(self, local_inst, master_inst):
    master_ipaddress = master_inst.private_ip_address
    local_ipaddress = local_inst.private_ip_address
    if self.verbose:
      sys.stderr.write("Joining cluster: %s:%d\n" % (master_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (master_ipaddress, self.couchbase_port, self.rest_endpoint_addnode)
    payload = {
      'user' : self.couchbase_user,
      'password' : self.couchbase_pass,
      'hostname' : "%s:%d" % (local_ipaddress, self.couchbase_port)
    }
    r_join = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_join.status_code)
    return r_join.status_code == 200

  def _failover_node(self, local_inst, master_inst):
    master_ipaddress = master_inst.private_ip_address
    local_ipaddress = local_inst.private_ip_address
    if self.verbose:
      sys.stderr.write("Triggering failover of node %s:%d from cluster: %s:%d\n" % (local_ipaddress, self.couchbase_port, master_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (master_ipaddress, self.couchbase_port, self.rest_endpoint_failover)
    payload = {
      'otpNode' : "ns_1@%s" % local_ipaddress
    }
    r_failover = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_failover.status_code)
    return r_failover.status_code == 200

  def _leave_cb_cluster(self, local_inst, master_inst):
    master_ipaddress = master_inst.private_ip_address
    local_ipaddress = local_inst.private_ip_address
    if self.verbose:
      sys.stderr.write("Leaving cluster: %s:%d\n" % (master_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (master_ipaddress, self.couchbase_port, self.rest_endpoint_delnode)
    payload = {
      'otpNode' : "ns_1@%s" % local_ipaddress
    }
    r_leave = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_leave.status_code)
    return r_leave.status_code == 200

  def _get_rebalance_progress(self, master_inst):
    ipaddress = master_inst.private_ip_address
    if self.verbose: sys.stderr.write("Getting rebalance progress from %s:%d\n" % (ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (ipaddress, self.couchbase_port, self.rest_endpoint_rebalance_status)
    r_rebstat = requests.get(r_url, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose: sys.stderr.write("Server returned %d\n" % r_rebstat.status_code)
    if r_rebstat.status_code == 200:
      return json.loads(r_rebstat.text)
    else:
      return None

  def _rebalance_cb_cluster(self, master_inst, nodelist, ejected_nodelist = []):
    master_ipaddress = master_inst.private_ip_address
    if self.verbose:
      sys.stderr.write("Rebalancing cluster: %s:%d\n" % (master_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (master_ipaddress, self.couchbase_port, self.rest_endpoint_rebalance)
    nodelist_flat = ",".join(nodelist) 
    ejected_nodelist_flat = ",".join(ejected_nodelist) 
    payload = {
      'ejectedNodes' : ejected_nodelist_flat,
      'knownNodes' : nodelist_flat
    }
    r_rebalance = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_rebalance.status_code)
    return r_rebalance.status_code == 200

  def _configure_web(self, instance):
    instance_ipaddress = instance.private_ip_address
    if self.verbose:
      sys.stderr.write("Configuring webserver on %s:%d\n" % (instance_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (instance_ipaddress, self.couchbase_port, self.rest_endpoint_settings)
    payload = {
      'username' : self.couchbase_user,
      'password' : self.couchbase_pass,
      'port' : 'SAME',
      'initStatus' : 'done'
    }
    r_webconf = requests.post(r_url, data=payload)
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_webconf.status_code)
    return r_webconf.status_code == 200

  def _configure_ram_quota(self, instance):
    instance_ipaddress =instance.private_ip_address
    if self.verbose:
      sys.stderr.write("Configuring ram quota on %s:%d\n" % (instance_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (instance_ipaddress, self.couchbase_port, self.rest_endpoint_status)
    payload = {
      'memoryQuota' : self.couchbase_memory,
    }
    r_webconf = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_webconf.status_code)
    return r_webconf.status_code == 200

  def _create_bucket(self, instance):
    instance_ipaddress = instance.private_ip_address
    if self.verbose:
      sys.stderr.write("Creating bucket on %s:%d\n" % (instance_ipaddress, self.couchbase_port))
    r_url = "http://%s:%d%s" % (instance_ipaddress, self.couchbase_port, self.rest_endpoint_createbucket)
    payload = {
      'bucketType' : 'couchbase',
      'proxyPort' : 11211,
      'authType' : 'sasl',
      'name' : self.couchbase_bucket,
      'replicaNumber' : 1,
      'saslPassword' : self.couchbase_pass,
      'ramQuotaMB' : self.couchbase_memory
    }
    r_createbuck = requests.post(r_url, data=payload, auth=(self.couchbase_user, self.couchbase_pass))
    if self.verbose:
      sys.stderr.write("Server returned %d\n" % r_createbuck.status_code)
    return r_createbuck.status_code == 200 or r_createbuck.status_code == 202

    
  def join_cluster(self):
    local = self._get_local_inst()
    if self.is_a_cluster(local.private_ip_address):
      sys.stderr.write("Local instance is already part of a cluster\n")
      return False
    candidates = self.find_cb_cluster()
    if ( self._check_cluster(candidates) ):
      master = self._get_random_node(candidates)
      return self._join_cb_cluster(local, master)
    else:
      sys.stderr.write("Cluster is inconsistent, manual check required\n")
      return False

  def leave_cluster(self):
    local = self._get_local_inst()
    candidates = self.find_cb_cluster()
    master = self._get_random_node(candidates)
    if not self.is_a_cluster(master.private_ip_address):
      sys.stderr.write("Master instance is not a cluster\n")
      return False

    members = self._get_nodes_in_cluster(master.private_ip_address)
    memberlist = [members[m]['otpNode'] for m in members.keys()]
    nodelabel = 'ns_1@%s' % local.private_ip_address
    if nodelabel not in memberlist:
      sys.stderr.write("Local instance is not part of the cluster\n")
      return False

    if self._failover_node(local, master):
      for retry in range(5):
	if self._leave_cb_cluster(local, master): break
        sys.stderr.write("Failed to leave cluster, retrying in 5 seconds")
        time.sleep(5)
      return True
    else:
      sys.stderr.write("Failed to leave cluster\n")
      return False
  
  def rebalance_cluster(self):
    local = self._get_local_inst()
    if not self.is_a_cluster(local.private_ip_address):
      sys.stderr.write("Local instance is not part of a cluster, cannot rebalance\n")
      return False

    members = self._get_nodes_in_cluster(local.private_ip_address)
    memberlist = [members[m]['otpNode'] for m in members.keys()]
    if self._rebalance_cb_cluster(local, memberlist):
      if self.wait_rebalance:
        while True:
          progress = self._get_rebalance_progress(local)
          status = progress.pop('status', 'unknown')
          if self.verbose:
            for node in progress:
              sys.stderr.write("[PROGRESS][%s] %s%%\n" % (node, float(progress[node]['progress']) * 100))
          if status != "running": break
          time.sleep(2)
      return True
    else:
      return False

  def create_local_cluster(self):
    local = self._get_local_inst()
    if self.is_a_cluster(local.private_ip_address):
      sys.stderr.write("Local instance is already part of a cluster\n")
      return False
    return self._configure_web(local) and self._configure_ram_quota(local) and self._create_bucket(local)

def main(argv):
  cbh = couchBaseHelper()

  def usage():
    print __doc__
    
  try:
    opts, args = getopt.getopt(argv, "ha:s:p:u:w:m:r:vt", ["help", "access=", "secret=", "cb-port=", "cb-user=", "cb-pass=", "cb-memory=", "vpc-role=", "verbose", "wait-rebalance" ])
  except getopt.GetoptError, e:
    sys.stderr.write("%s\n" % str(e))
    usage()
    sys.exit(2)
  
  cbh.AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
  cbh.AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')

  for opt, arg in opts:
    if opt in ("-h", "--help"):
      usage()
      sys.exit()
    elif opt in ("-a", "--access"):
      cbh.AWS_ACCESS_KEY_ID = arg
    elif opt in ("-s", "--secret"):
      cbh.AWS_SECRET_ACCESS_KEY = arg
    elif opt in ("-v", "--verbose"):
      cbh.verbose = True
    elif opt in ("-t", "--wait-rebalance"):
      cbh.wait_rebalance = True
    elif opt in ("-p", "--cb-port"):
      cbh.couchbase_port = int(arg)
    elif opt in ("-u", "--cb-user"):
      cbh.couchbase_user = arg
    elif opt in ("-w", "--cb-pass"):
      cbh.couchbase_pass = arg
    elif opt in ("-b", "--cb-bucket"):
      cbh.couchbase_bucket = arg
    elif opt in ("-r", "--vpc-role"):
      cbh.vpc_role = arg
    elif opt in ("-m", "--cb-memory"):
      cbh.couchbase_memory = arg


  try:
    arg = args[0]
  except IndexError:
    sys.stderr.write("Missing command\n")
    usage()
    sys.exit(-10)

  if arg == "create":
    if not cbh.create_local_cluster():
      sys.stderr.write("Failed to create local cluster\n")
      sys.exit(-10)
  elif arg == "join":
    if not cbh.join_cluster():
      sys.stderr.write("Failed to join cluster\n")
      sys.exit(-10)
  elif arg == "leave":
    if not cbh.leave_cluster():
      sys.stderr.write("Failed to leave cluster\n")
      sys.exit(-10)
  elif arg == "rebalance":
    if not cbh.rebalance_cluster():
      sys.stderr.write("Failed to rebalance cluster\n")
      sys.exit(-10)
  elif arg == "auto":
    if cbh.verbose: sys.stderr.write("[AUTO] Scanning local node for couchbase clusters\n")
    if cbh.is_a_cluster("127.0.0.1"):
      if cbh.verbose: sys.stderr.write("[AUTO] This host is already part of a cluster\n")
      sys.exit(0)
    if cbh.verbose: sys.stderr.write("[AUTO] Scanning EC2 for existing cluster\n")
    if len(cbh.find_cb_cluster()) > 0:
      if cbh.verbose: sys.stderr.write("[AUTO] Found cluster, joining in\n")
      if not cbh.join_cluster():
        sys.stderr.write("[AUTO] Failed to join cluster\n")
        sys.exit(-10)
      if cbh.verbose: sys.stderr.write("[AUTO] Join successful, rebalancing\n")
      if not cbh.rebalance_cluster():
        sys.stderr.write("[AUTO] Failed to rebalance cluster\n")
        sys.exit(-10)
    else:
      if cbh.verbose: sys.stderr.write("[AUTO] Cluster not found, proceeding with election\n")
      if cbh.should_i_be_master():
        if cbh.verbose: sys.stderr.write("[AUTO] Looks like I should be the master, creating local cluster\n")
        if not cbh.create_local_cluster():
          sys.stderr.write("[AUTO] Failed to create local cluster\n")
          sys.exit(-10)
        if cbh.verbose: sys.stderr.write("[AUTO] Create successful\n")
      else:
        if cbh.verbose: sys.stderr.write("[AUTO] Someone else is supposed to build this cluster, run me again later\n")
  else:
    sys.stderr.write("Unrecognized command: %s\n" % arg)
    usage()
    sys.exit(-10)

  sys.exit(0)

if __name__ == "__main__":
  main(sys.argv[1:])
