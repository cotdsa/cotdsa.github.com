class TimeoutError(Exception):
    def __init__(self, errmsg):
        self.errmsg = errmsg

    def __repr__(self):
        return "TimeoutError(%s)" % self.errmsg

    def __str__(self):
        return "%s" % self.errmsg