import sys
import os
import signal
import errno
import logging
from functools import wraps

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def cache(expiration_time=None, should_cache_fn=None):
    def decorator(func):
        def wrapper(self, *arg, **kw):
            @wraps(func)
            def creator():
                return func(self, *arg, **kw)

            if not self.cache_enable or not self.cache_region:
                log.info("Caching disabled, going online")
                return creator()

            namespace = self.get_instance_id()
            key_generator = self.cache_region.function_key_generator(namespace, func, to_str=str)
            key = key_generator(*arg, **kw)
            timeout = expiration_time
            log.info("Using cache to access value with key=%s (ttl=%s)" % (key, timeout))
            return self.cache_region.get_or_create(key, creator, timeout, should_cache_fn)

        return wraps(func)(wrapper)

    return decorator