import os
import yaml
import boto
import boto.utils
import boto.ec2
import boto.cloudformation
import boto.ec2.autoscale
import logging
import contextlib
import socket
import urllib2
from inspect import isfunction

from .utils import cache, get_nested, boto_tags_to_dict, nested_dict_to_flat
from .exceptions import TimeoutError

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


CHECK_TIMEOUT = 3


class metadataHelper:

    def __init__(self, caching):

        # Am I on AWS?
        self.check_ec2()

        # Initialise local attributes
        self.instance_metadata = None
        self.instance_identity = None
        self.instance_vpc = None
        self.instance_cf = None
        self.instance_asg = None
        self.ec2connection = None
        self.cfconnection = None
        self.asgconnection = None
        self.cache_enable = False
        self.cache_region = None

        if caching:
            # Setup caching
            log.info("Enabling cache")
            try:
                from dogpile.cache import make_region

                homedir = os.path.expanduser('~')
                cachefilename = os.path.join(homedir, '.cg-awsattr-cache.dbm')
                self.cache_region = make_region().configure(
                    "dogpile.cache.dbm",
                    expiration_time=300,
                    arguments={
                        "filename": cachefilename
                    }
                )
                self.cache_enable = True
            except Exception, e:
                log.error("Cannot enable caching. Error = %s" % e.message)
                self.cache_enable = False

        # Initialise instance metadata and identity
        log.info('Loading instance metadata')
        self.instance_metadata = self.get_instance_meta()
        log.info('Loading instance identity')
        self.instance_identity = self.get_instance_identity()

    def retrieve(self, key, separator='.'):
        if key:
            log.debug("Trying to retrieve key %s" % key)
            comp = key.split(separator)
            log.debug("Resolving callable for key")
            callb, remaining = self.resolve_callable(comp, self.ROUTE_KEYS)
            log.debug("Accessing remaining path %s with function %s" % (str(remaining), callb))
            if isfunction(callb):
                out = get_nested(callb(self), remaining, None)
                if out:
                    if isinstance(out, basestring):
                        return out
                    else:
                        result = nested_dict_to_flat(out, prefix=key, separator=separator)
                        return [(item, result[item]) for item in result]
        else:
            route_keys = nested_dict_to_flat(self.ROUTE_KEYS, separator=separator)
            ret_list = list()
            for route_key in route_keys:
                call_res = route_keys[route_key](self)
                if not call_res:
                    continue
                if isinstance(call_res, basestring):
                    ret_list.append((route_key, call_res))
                else:
                    result = nested_dict_to_flat(call_res, prefix=route_key, separator=separator)
                    route_list = [(item, result[item]) for item in result]
                    ret_list = ret_list + route_list
            return ret_list

    def resolve_callable(self, components, router):
        assert isinstance(components, list)
        # Pop the first entry
        try:
            itm = components.pop(0)
        except IndexError:
            return None, None
        log.debug("POPd entry = %s" % itm)
        try:
            sub = router[itm]
            if isfunction(sub):
                log.debug("Found callable! = %s" % sub)
                return sub, components
            elif isinstance(sub, dict):
                log.debug("Recursing... remaining items = %s" % str(components))
                return self.resolve_callable(components, sub)
            else:
                log.error("Unexpected type in route definition")
                return None, None
        except KeyError:
            return None, None

    @staticmethod
    def check_ec2():
        url = 'http://169.254.169.254/latest/'
        logging.debug('Checking if host is running on EC2')
        original = socket.getdefaulttimeout()
        socket.setdefaulttimeout(CHECK_TIMEOUT)
        try:
            req = urllib2.Request(url)
            r = urllib2.urlopen(req)
            r.read()
        except urllib2.URLError:
            raise TimeoutError("This host doesn't seem to run on EC2")

        finally:
            socket.setdefaulttimeout(original)

    @contextlib.contextmanager
    def _get_ec2_connection(self):
        if not isinstance(self.ec2connection, boto.ec2.connection.EC2Connection):
            log.info('Connecting to EC2 on region %s' % self.get_instance_region())
            self.ec2connection = boto.ec2.connect_to_region(region_name=self.get_instance_region())
        yield self.ec2connection

    @contextlib.contextmanager
    def _get_cf_connection(self):
        if not isinstance(self.cfconnection, boto.cloudformation.CloudFormationConnection):
            log.info('Connecting to CloudFormation on region %s' % self.get_instance_region())
            self.cfconnection = boto.cloudformation.connect_to_region(region_name=self.get_instance_region())
        yield self.cfconnection

    @contextlib.contextmanager
    def _get_asg_connection(self):
        if not isinstance(self.asgconnection, boto.ec2.autoscale.AutoScaleConnection):
            log.info('Connecting to Autoscale on region %s' % self.get_instance_region())
            self.asgconnection = boto.ec2.autoscale.connect_to_region(region_name=self.get_instance_region())
        yield self.asgconnection

    def get_instance_region(self):
        if self.instance_identity:
            return self.instance_identity['region']
        return None

    def get_instance_id(self):
        if self.instance_metadata:
            return self.instance_metadata['instance-id']
        return None

    def __get_nic(self, index=0):
        macs = self.instance_metadata['network']['interfaces']['macs']
        for mac in macs:
            if int(self.instance_metadata['network']['interfaces']['macs'][mac]['device-number']) == index:
                return self.instance_metadata['network']['interfaces']['macs'][mac]
        raise LookupError

    def get_subnet_id(self, index=0):
        nic = self.__get_nic(index)
        return nic['subnet-id']

    def get_vpc_id(self, index=0):
        nic = self.__get_nic(index)
        return nic['vpc-id']

    def get_asg_id(self):
        try:
            return self.get_instance_tags()['aws:autoscaling:groupName']
        except KeyError:
            return None

    def is_instance_in_vpc(self):
        if isinstance(self.instance_vpc, bool):
            return self.instance_vpc
        try:
            self.__get_nic()['vpc-id']
        except KeyError:
            self.instance_vpc = False
            return False
        self.instance_vpc = True
        return True

    def is_instance_in_cf(self):
        if isinstance(self.instance_cf, bool):
            return self.instance_cf
        try:
            self.get_instance_tags()['aws:cloudformation:logical-id']
        except KeyError:
            self.instance_cf = False
            return False
        self.instance_cf = True
        return True

    def is_instance_in_asg(self):
        if isinstance(self.instance_asg, bool):
            return self.instance_asg
        try:
            self.get_instance_tags()['aws:autoscaling:groupName']
        except KeyError:
            self.instance_asg = False
            return False
        self.instance_asg = True
        return True

    def get_ec2_resource_tags(self, resource_id):
        with self._get_ec2_connection() as ec2conn:
            try:
                return boto_tags_to_dict(ec2conn.get_all_tags(filters={'resource-id': resource_id}))
            except boto.exception.BotoServerError:
                return list()

    def get_asg_resource_tags(self, asg_id):
        with self._get_asg_connection() as asgconn:
            try:
                all_tags = asgconn.get_all_tags()
                # Filtering is not yet implemented by boto. Do it in code
                filtd_tags = []
                for tag in all_tags:
                    if tag.resource_id == asg_id:
                        filtd_tags.append(tag)
                return boto_tags_to_dict(filtd_tags)
            except boto.exception.BotoServerError:
                return list()

    def get_cf_resource_meta(self, stack_name, resource_id):
        with self._get_cf_connection() as cfconn:
            try:
                return cfconn.describe_stack_resource(stack_name_or_id=stack_name, logical_resource_id=resource_id)
            except boto.exception.BotoServerError:
                return dict()

    @cache(expiration_time=1200)
    def get_instance_meta(self):
        log.debug("get_instance_meta()")
        meta = boto.utils.get_instance_metadata()

        try:
            # Strip IAM data if present
            del meta['iam']
            # Duplicate primary interface attributes so it can be statically referenced
            primary_mac = meta['mac']
            meta_struct = meta['network']['interfaces']['macs'][primary_mac]
            meta['network']['primary'] = meta_struct
        except KeyError:
            pass

        return meta

    @cache(expiration_time=1200)
    def get_instance_identity(self):
        log.debug("get_instance_identity()")
        return boto.utils.get_instance_identity()['document']

    @cache(expiration_time=1200)
    def get_instance_tags(self):
        log.debug("get_instance_tags()")
        instance_id = self.get_instance_id()
        return self.get_ec2_resource_tags(instance_id)

    @cache(expiration_time=604800)
    def get_subnet_tags(self):
        log.debug("get_subnet_tags()")
        if not self.is_instance_in_vpc():
            return dict()
        subnet_id = self.get_subnet_id()
        return self.get_ec2_resource_tags(subnet_id)

    @cache(expiration_time=604800)
    def get_vpc_tags(self):
        log.debug("get_vpc_tags()")
        if not self.is_instance_in_vpc():
            return dict()
        vpc_id = self.get_vpc_id()
        return self.get_ec2_resource_tags(vpc_id)

    @cache(expiration_time=604800)
    def get_asg_tags(self):
        log.info("get_asg_tags()")
        if not self.is_instance_in_asg():
            return dict()
        asg_id = self.get_asg_id()
        log.info("get_asg_tags() asd")
        return self.get_asg_resource_tags(asg_id)

    def get_cf_meta(self, cf_stack_name, cf_resource_id):
        log.debug("get_cf_meta(%s)", cf_resource_id)
        if not self.is_instance_in_cf():
            return dict()
        #cf_stack_name = self.get_instance_tags()['aws:cloudformation:stack-name']
        #cf_resource_id = self.get_instance_tags()['aws:cloudformation:logical-id']
        call_result = self.get_cf_resource_meta(cf_stack_name, cf_resource_id)
        try:
            resource = call_result['DescribeStackResourceResponse']['DescribeStackResourceResult'][
                'StackResourceDetail']
            try:
                # Try to parse metadata in json
                metadata = resource['Metadata']
                if not metadata:
                    del resource['Metadata']
                    raise KeyError
                decoded_meta = yaml.load(metadata)
                # Woohoo it worked, we can now merge the array and remove the original
                resource['meta'] = decoded_meta
                del resource['Metadata']
            except KeyError:
                log.info('No metadata information found on CF resource')
                pass
            except yaml.YAMLError:
                log.error('Error while decoding CF resource metadata. Is it proper JSON?')
                # Metadata entry is not deserialisable, let's just move on with life
                pass

            return resource
        except KeyError:
            log.error('Cannot retrieve CF resource information')
            return dict()

    @cache(expiration_time=1200)
    def get_inst_cf_meta(self):
        stack_name = self.get_instance_tags()['aws:cloudformation:stack-name']
        inst_logical_id = self.get_instance_tags()['aws:cloudformation:logical-id']
        return self.get_cf_meta(stack_name, inst_logical_id)

    @cache(expiration_time=1200)
    def get_asg_cf_meta(self):
        log.debug("get_asg_cf_meta()")
        if not self.is_instance_in_asg():
            return dict()
        try:
            asg_stack_name = self.get_asg_tags()['aws:cloudformation:stack-name']
            asg_logical_id = self.get_asg_tags()['aws:cloudformation:logical-id']
        except (KeyError,TypeError):
            return dict()
        return self.get_cf_meta(asg_stack_name, asg_logical_id)

    ROUTE_KEYS = {
        'aws': {
            'inst': {
                'meta': get_instance_meta,
                'identity': get_instance_identity,
                'tags': get_instance_tags
            },
            'vpc': {
                'tags': get_vpc_tags
            },
            'subnet': {
                'tags': get_subnet_tags
            },
            'asg': {
                'id': get_asg_id,
                'tags': get_asg_tags,
                'cf': get_asg_cf_meta
            },
            'cf': get_inst_cf_meta
        }
    }
