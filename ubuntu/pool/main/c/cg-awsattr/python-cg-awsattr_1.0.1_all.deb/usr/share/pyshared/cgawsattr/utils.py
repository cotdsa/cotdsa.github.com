import logging
from functools import wraps

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def cache(expiration_time=None, should_cache_fn=None):
    def decorator(func):
        def wrapper(self, *arg, **kw):
            @wraps(func)
            def creator():
                return func(self, *arg, **kw)

            if not self.cache_enable or not self.cache_region:
                log.info("Caching disabled, going online")
                return creator()

            namespace = self.get_instance_id()
            key_generator = self.cache_region.function_key_generator(namespace, func, to_str=str)
            key = key_generator(*arg, **kw)
            timeout = expiration_time
            log.info("Using cache to access value with key=%s (ttl=%s)" % (key, timeout))
            return self.cache_region.get_or_create(key, creator, timeout, should_cache_fn)

        return wraps(func)(wrapper)

    return decorator


def get_nested(d, list_of_keys, default):
    for k in list_of_keys:
        if k not in d:
            return default
        d = d[k]
    return d


def boto_tags_to_dict(array_of_tags):
    out_dict = dict()
    for item in array_of_tags:
        try:
            item_name = item.name
        except AttributeError:
            item_name = item.key
        out_dict[item_name] = item.value
    return out_dict


def nested_dict_to_flat(inp_dict, separator, prefix=None, ):
    output = {}
    for key in inp_dict:
        if isinstance(inp_dict[key], dict):
            if prefix:
                new_prefix = '%s%s%s' % (prefix, separator, key)
            else:
                new_prefix = key
            merge_arr = nested_dict_to_flat(inp_dict[key], prefix=new_prefix, separator=separator)
            output.update(merge_arr)
        else:
            if prefix:
                output['%s%s%s' % (prefix, separator, key)] = inp_dict[key]
            else:
                output[key] = inp_dict[key]
    return output